import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { GoogleMapsModule} from "@angular/google-maps";
import { CarouselModule } from "ngx-owl-carousel-o";




import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { HomeModuleModule } from "./home-module/home-module.module";
import { UserAuthModule } from "./user-auth/user-auth.module";
import { AdminModule } from "./admin/admin.module";



import { AppComponent } from './app.component';

import { CalendarModule, DatePickerModule, TimePickerModule, DateRangePickerModule, DateTimePickerModule } from '@syncfusion/ej2-angular-calendars';
import { TurfModalComponent } from './turf-modal/turf-modal.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';








@NgModule({
  declarations: [
    AppComponent,

    TurfModalComponent,
     PagenotfoundComponent,   
   
   
    
  
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    HomeModuleModule,
    UserAuthModule,
    AdminModule,
    ReactiveFormsModule,
    FormsModule,
    CalendarModule, DatePickerModule, TimePickerModule, DateRangePickerModule, DateTimePickerModule,
    GoogleMapsModule,
    CarouselModule
   
   
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
