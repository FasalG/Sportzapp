import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserMngmntComponent } from './user-mngmnt/user-mngmnt.component';
import { TurfMngmntComponent } from './turf-mngmnt/turf-mngmnt.component';
import { BookingMngmntComponent } from './booking-mngmnt/booking-mngmnt.component';
import { ReportComponent } from './report/report.component';
import { TransMngmntComponent } from './trans-mngmnt/trans-mngmnt.component';


@NgModule({
  declarations: [
    AdminComponent,
    DashboardComponent,
    UserMngmntComponent,
    TurfMngmntComponent,
    BookingMngmntComponent,
    ReportComponent,
    TransMngmntComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule

  ]
})
export class AdminModule { }
