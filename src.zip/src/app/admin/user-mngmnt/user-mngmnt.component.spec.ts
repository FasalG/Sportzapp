import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserMngmntComponent } from './user-mngmnt.component';

describe('UserMngmntComponent', () => {
  let component: UserMngmntComponent;
  let fixture: ComponentFixture<UserMngmntComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UserMngmntComponent]
    });
    fixture = TestBed.createComponent(UserMngmntComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
