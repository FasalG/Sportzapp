import { Component, HostListener} from '@angular/core';

@Component({
  selector: 'app-home-module',
  templateUrl: './home-module.component.html',
  styleUrls: ['./home-module.component.css'],
 
})
export class HomeModuleComponent {

  change:boolean=false;
  headerVariable:boolean=false;
  showGallery:boolean=false;
  showCard:boolean=false;




  @HostListener('document:scroll')
  onScroll(){
    if (document.body.scrollTop>150 || document.documentElement.scrollTop>150) {
      this.change=true;
      this.headerVariable=true;
      if (document.body.scrollTop>300 || document.documentElement.scrollTop>300) {
        this.showGallery=true
      }
      else{
        this.showGallery=false
      }

    }
    else{
      this.change=false;
      this.headerVariable=false;    
    
    }
    if (document.body.scrollTop>800 || document.documentElement.scrollTop>800) {
      this.showCard=true
    }
    else{
      this.showCard=false
    }

  }
}


