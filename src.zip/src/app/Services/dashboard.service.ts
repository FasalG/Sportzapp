import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  incomeURL:any="http://192.168.1.22:8000/admin_app/admin_income/"

  constructor(private http:HttpClient) { }

  getIncome(){
    return this.http.get<any>(this.incomeURL)
  }

  filterIncom(data:any){
      this.http.post<any>(this.incomeURL,data).subscribe((response)=>{console.log(response)})
  }
}
