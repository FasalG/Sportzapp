import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransServiceService {

  bookingUrl:any="http://192.168.1.69:9000/admin_app/booking_list/"
  transUrl:any="http://192.168.1.69:9000/admin_app/transaction_list/"

  constructor(private http: HttpClient) { }

  getTransDetails(){
    return this.http.get<any>(this.transUrl)
  }
  getBookingDetails(){
    return this.http.get<any>(this.bookingUrl)
  }
}
