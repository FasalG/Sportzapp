import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransServiceService {

  bookingUrl:any="http://192.168.1.22:8000/admin_app/booking_list/"
  bookingcancelUrl:any="http://192.168.1.22:8000/admin_app/booking_cancel/"

  transUrl:any="http://192.168.1.22:8000/admin_app/transaction_list/"

  constructor(private http: HttpClient) { }

  getTransDetails(){
    return this.http.get<any>(this.transUrl)
  }


  // booking management
  getBookingDetails(){
    return this.http.get<any>(this.bookingUrl)
  }

  cancelBookingInfo(bookingidinfo:any){
     return this.http.delete(this.bookingcancelUrl + bookingidinfo +'/').toPromise()
  }

}
