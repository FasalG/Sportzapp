import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  usersUrl:any="http://192.168.1.31:9000/owner/register/"
  turfownerloginUrl:any="http://192.168.1.31:9000/owner/login/"

  constructor(private http:HttpClient, private toastrService: ToastrService, private router:Router) { }

  turfownerRegister(turfownerdata:any){
    this.http.post<any>(this.usersUrl,turfownerdata).subscribe(
      (response) => {
        console.log('Registration successful!', response);
        this.toastrService.success('Signup Successful!');
      },
      (error) => {
        console.error('Registration failed!', error);
        this.toastrService.error('Signup Failed! Please check the form.');
      }
    )   
  }

  loginownertoken:any

  turfownerLogin(ownerloginData:any){
    this.http.post<any>(this.turfownerloginUrl,ownerloginData).subscribe(
      (response)=>{
        console.log('Registration successful!', response)
        this.loginownertoken=response
        
        this.router.navigateByUrl('/owner')
      },
      (error)=>{
        console.error('Registration failed!', error)
      }
    )
    
  }


}
