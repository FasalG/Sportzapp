import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthServiceService } from "../Services/auth-service.service";

@Injectable({
  providedIn: 'root'
})
export class TurfownerpageService {

  turfdetailsURL:any="https://1ffb-2402-3a80-1927-da72-8024-3cdc-ff4b-90dc.ngrok-free.app/owner/turf/"
  turfdeleteUrl:any="https://1ffb-2402-3a80-1927-da72-8024-3cdc-ff4b-90dc.ngrok-free.app/owner/turf_management/"
  paymenthisatoryURL:any="https://1ffb-2402-3a80-1927-da72-8024-3cdc-ff4b-90dc.ngrok-free.app/owner/payment/"
  amenityURL:any="https://1ffb-2402-3a80-1927-da72-8024-3cdc-ff4b-90dc.ngrok-free.app/owner/amenity/"

  predictedbookingforeachturfURL:any="https://6012-116-68-110-250.ngrok-free.app/admin_app/display_predicted_weekly_booking/"


  ownerid:any=localStorage.getItem('ownerid')
  ownertoken:any=localStorage.getItem('ownertoken')

  constructor(private http:HttpClient) {

  }

  getAmenity(){
   return this.http.get<any>(this.amenityURL)
  }

  getBookingprediction(turfid:any){


  return this.http.get<any>(this.predictedbookingforeachturfURL + turfid + '/')
  }
 

  getownerTurfs(){

    const headers = new HttpHeaders({     
        'Authorization': `token ${this.ownertoken}`      
    })   

    return this.http.get<any>(this.turfdetailsURL +this.ownerid +'/',{headers})
    
  }

  getOwnerPaymentHistory(){
    const headers = new HttpHeaders({     
      'Authorization': `token ${this.ownertoken}`      
  })   

  return this.http.get<any>(this.paymenthisatoryURL+ this.ownerid + '/', {headers})
  }


  deleteownerTurf(id:any){

    const headers = new HttpHeaders({     
      'Authorization': `token ${this.ownertoken}`      
  })   

    return this.http.delete<any>(this.turfdeleteUrl+id+"/", {headers}).toPromise().then((d:any)=>{
      console.log(d)
    })
  }

  creteturf(turfdet:any){

    const headers = new HttpHeaders({     
      'Authorization': `token ${this.ownertoken}`      
  })   

    this.http.post<any>(this.turfdetailsURL + this.ownerid+'/', turfdet, {headers}).subscribe((response)=>{
      console.log('succes', response)
    
    })
  }
}
