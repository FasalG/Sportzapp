import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class ownerService{
    turfOwnersUrl:any="https://1ffb-2402-3a80-1927-da72-8024-3cdc-ff4b-90dc.ngrok-free.app/admin_app/owner_list/";
    deletOwnerUrl:any="https://1ffb-2402-3a80-1927-da72-8024-3cdc-ff4b-90dc.ngrok-free.app/owner_retrieve_delete/"



    constructor(private http: HttpClient) { }

    turfOwner() {
        return this.http.get<any>(this.turfOwnersUrl);    
      }

      TurfOwnerdelete(ownerid:any){
        return this.http.delete(this.deletOwnerUrl+ownerid+'/').toPromise()
      }


}