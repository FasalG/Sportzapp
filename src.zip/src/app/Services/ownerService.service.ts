import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class ownerService{
    turfOwnersUrl:any="http://192.168.1.31:9000/owner/turf/1/";
    deletOwnerUrl:any="http://192.168.1.31:9000/owner/turf_management/"



    constructor(private http: HttpClient) { }

    turfOwner() {
        return this.http.get<any>(this.turfOwnersUrl);    
      }

      TurfOwnerdelete(ownerid:any){
        this.http.delete(this.deletOwnerUrl+ownerid+'/').toPromise().then((d:any)=>{
                console.log(d)
        })
      }


}