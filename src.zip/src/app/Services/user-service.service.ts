import { Injectable } from '@angular/core';
import { HttpClient ,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})


export class UserServiceService {

  constructor(private http: HttpClient) { }

  usersUrl:any="http://192.168.1.22:8000/admin_app/customer_list/"
  deleteuserUrl:any="http://192.168.1.22:8000/admin_app/customer_retrieve_delete/"


  getUsers(){
    return this.http.get<any>(this.usersUrl)
  }

  deleteUser(itemId: any){

    return this.http.delete(this.deleteuserUrl+itemId + '/').toPromise()
    
  }
}


